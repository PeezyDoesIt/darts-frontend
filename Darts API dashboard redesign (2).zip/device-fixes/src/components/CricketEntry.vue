<template>
  <div class="cricket">

    <div class="cricket-board-scroll">
      <TransitionGroup tag="div" name="tile-vanish" class="cricket-board">
        <button
          v-for="target in effectiveTargets"
          :key="String(target)"
          v-show="closedTargetDisplay !== 'hide' || !myClosed(target)"
          v-ripple
          class="board-tile"
          :class="{
            closed: myClosed(target) && closedTargetDisplay === 'show',
            active: (roundHits[String(target)] ?? 0) > 0
          }"
          :disabled="myClosed(target)"
          @click="handleTileClick(target)"
        >
          <span class="target-label" :class="{ 'target-label-bull': target === 'bull' }" :style="{ color: targetColor, filter: `drop-shadow(0 0 6px ${targetColor}80)` }">{{ target === 'bull' ? '🎯' : target }}</span>

          <div class="pips-wrap" :class="`pips-${pipStyle ?? 'blocks'}`" :style="{ '--pip': pipColor || 'var(--pink)' }">
            <span
              v-for="n in mtc" :key="n"
              class="pip"
              :class="{ existing: pipIsExisting(target, n), round: pipIsRound(target, n) }"
              @click.stop="handlePipClick(target, n)"
            >{{ pipGlyph(target, n) }}</span>
          </div>

          <span v-if="myClosed(target)" class="closed-badge">✓ CLOSED</span>
          <span v-else-if="(roundHits[String(target)] ?? 0) > 0" class="hit-badge">+{{ roundHits[String(target)] }}</span>
          <span v-else class="hit-badge invisible">+0</span>
        </button>
      </TransitionGroup>
    </div>

<div class="submit-row">
      <!-- Left area: timer fill is constrained here, never reaches the button -->
      <ThrowTimer
        :timeLeft="throwTimeLeft" :duration="throwTimerDuration"
        :paused="throwPaused" :locked="showPauseLocked"
        @toggle="emit('toggleThrowPause')"
      >
        <span v-if="totalHitsThisRound > 0" class="hits-text">
          {{ totalHitsThisRound }} hit{{ totalHitsThisRound !== 1 ? 's' : '' }} this round
        </span>
        <span v-else class="round-label-text" :style="{ color: targetColor }">Round {{ round }}</span>
      </ThrowTimer>
      <button v-ripple class="btn btn-gold submit-inline-btn" :disabled="submitted" @click="submit">
        NEXT
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { CRICKET_TARGETS, type PipStyle, type PlayerScore } from '../types/index'
import { resolveTargetColor } from '../lib/targetColor'
import ThrowTimer from './ThrowTimer.vue'
import { playShotgun, playThemedBuzzer, playThemedBullseye } from '../composables/useSounds'
import { speak, speakOhBaby } from '../composables/useSpeech'
import { useSettingsStore } from '../stores/settings'

const settingsStore = useSettingsStore()

const props = defineProps<{
  playerId: string
  scores: Record<string, PlayerScore>
  round: number
  closedTargetDisplay?: 'show' | 'hide'
  avatarUrl?: string | null
  playerColor?: string
  playerBackground?: string | null
  targetLabelColor?: string | null
  /** Colour of a filled pip. Falls back to the app pink, which is what they always were. */
  pipColor?: string | null
  /** Shape of a mark. Falls back to the filled blocks they always were. */
  pipStyle?: PipStyle | null
  marksToClose?: number
  throwTimeLeft?: number
  throwTimerDuration?: number
  throwPaused?: boolean
  /** Set for a moment when the timer is tapped while pausing is locked. */
  showPauseLocked?: boolean
  wildTargets?: number[]
  wildPlayerMarks?: Record<string, number>
}>()

const targetColor = computed(() =>
  resolveTargetColor(props.targetLabelColor, props.playerColor, props.playerBackground))

const emit = defineEmits<{
  submit: [hits: Record<string, number>]
  toggleThrowPause: []
}>()

type EffTarget = number | 'bull'
const roundHits = ref<Record<string, number>>({})
const submitted = ref(false)

const myScore = computed(() => {
  const s = props.scores[props.playerId]
  return s?.kind === 'cricket' ? s : null
})
const effectiveTargets = computed((): readonly EffTarget[] => {
  if (props.wildTargets) return [...props.wildTargets, 'bull']
  return CRICKET_TARGETS as readonly EffTarget[]
})
const existingMarks = computed((): Record<string, number> => {
  if (props.wildPlayerMarks) return props.wildPlayerMarks
  return myScore.value?.data.marks ?? { 20: 0, 19: 0, 18: 0, 17: 0, 16: 0, 15: 0, bull: 0 }
})
const totalHitsThisRound = computed(() =>
  Object.values(roundHits.value).reduce((a, b) => a + (b ?? 0), 0)
)

const mtc = computed(() => props.marksToClose ?? 3)

/**
 * What a single mark shows.
 *
 * Only the Classic style draws anything: a board is scored with a slash for the first hit,
 * crossed for the second and ringed for the third, so the glyph depends on which mark it is
 * rather than on the target being closed. The other styles are drawn in CSS and show a
 * closing cross exactly as they always did.
 */
function pipGlyph(target: EffTarget, n: number): string {
  if (props.pipStyle !== 'marks') return myClosed(target) ? '✕' : ''
  if (!pipIsExisting(target, n) && !pipIsRound(target, n)) return ''
  return n === 1 ? '/' : n === 2 ? '✕' : '⊗'
}
function myClosed(target: EffTarget) { return (existingMarks.value[String(target)] ?? 0) >= mtc.value }
function pipIsExisting(target: EffTarget, n: number) { return (existingMarks.value[String(target)] ?? 0) >= n }
function pipIsRound(target: EffTarget, n: number) {
  const existing = existingMarks.value[String(target)] ?? 0
  return existing < n && existing + (roundHits.value[String(target)] ?? 0) >= n
}
function playBullSound() {
  const s = settingsStore.bullseyeSound
  // TTS options always take priority
  if (s === 'tts-bullseye') { speak('Bullseye!'); return }
  if (s === 'tts-oh-baby') { speakOhBaby(); return }
  if (s === 'tts-oh-yeah') { speak('Oh yeah, right in the bull motherfucker'); return }
  // Non-default theme: play themed bullseye regardless of bullseyeSound setting
  const theme = settingsStore.soundTheme
  if (theme !== 'default') { playThemedBullseye(theme); return }
  // Default theme: respect bullseyeSound setting
  if (s === 'buzzer') { playThemedBuzzer('default'); return }
  playShotgun()
}

function handleTileClick(target: EffTarget) {
  if (myClosed(target)) return
  const key = String(target)
  const existing = existingMarks.value[key] ?? 0
  const max = mtc.value - existing
  const current = roundHits.value[key] ?? 0
  const next = current >= max ? 0 : current + 1
  roundHits.value = { ...roundHits.value, [key]: next }
  if (target === 'bull' && next > current) playBullSound()
}

// Tapping pip N directly sets the hit count so that pips 1..N are all lit.
// Tapping the already-selected pip resets to 0.
function handlePipClick(target: EffTarget, n: number) {
  if (myClosed(target)) return
  const key = String(target)
  const existing = existingMarks.value[key] ?? 0
  if (n <= existing) return // already a committed mark, can't change it
  const hitsNeeded = n - existing
  const current = roundHits.value[key] ?? 0
  const next = current === hitsNeeded ? 0 : hitsNeeded
  roundHits.value = { ...roundHits.value, [key]: next }
  if (target === 'bull' && next > current) playBullSound()
}
function submit() {
  if (submitted.value) return
  submitted.value = true
  const hits: Record<string, number> = {}
  for (const t of effectiveTargets.value) hits[String(t)] = roundHits.value[String(t)] ?? 0
  emit('submit', hits)
  roundHits.value = {}
}

defineExpose({ submit, submitted })
</script>

<style scoped>
.cricket { flex: 1; display: flex; flex-direction: column; overflow: hidden; min-height: 0; position: relative; }

.cricket-board-scroll { flex: 1; min-height: 0; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain; position: relative; z-index: 1; }

.cricket-board {
  display: flex;
  flex-direction: column;
  padding: 6px 16px;
  gap: 10px;
  min-height: 100%;
}

/* Hide-closed-targets animation */
.tile-vanish-leave-active {
  transition: opacity 0.4s ease, transform 0.4s ease, flex 0.4s ease, min-height 0.4s ease, padding 0.4s ease, margin 0.4s ease;
  overflow: hidden;
}
.tile-vanish-leave-to {
  opacity: 0;
  transform: scale(0.7);
  flex: 0 !important;
  min-height: 0 !important;
  padding-top: 0 !important;
  padding-bottom: 0 !important;
  margin: 0 !important;
}

.board-tile {
  display: flex; align-items: stretch; width: 100%; padding: 8px 24px; gap: 0;
  flex: 1; min-height: 48px; position: relative;
  background: rgba(0,0,0,0.72); border: 2px solid rgba(255,255,255,0.35);
  cursor: pointer; transition: all 0.15s; -webkit-tap-highlight-color: transparent; text-align: left;
  position: relative; overflow: hidden;
}
.board-tile:not(:disabled):active { transform: scale(0.98); }
.board-tile.closed { cursor: default; }
.board-tile.closed .pip.existing { background: #cc0000; border-color: #cc0000; box-shadow: none; color: #000; }

.target-label { font-size: clamp(120px, 20dvh, 220px); font-family: var(--font-display); letter-spacing: 0.05em; width: clamp(150px, 20dvh, 240px); flex-shrink: 0; display: flex; align-items: center; overflow: hidden; }
.target-label-bull { font-size: clamp(150px, 26dvh, 280px); }
.pips-wrap { display: flex; align-items: stretch; gap: 20px; flex: 1; padding: 14px 0; margin-left: 24px; }
.pip { flex: 1; min-width: 0; border-radius: 10px; border: 3px solid rgba(255,255,255,0.35); background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center; transition: all 0.2s; font-size: clamp(28px, 5dvh, 60px); font-weight: 900; font-family: var(--font-display); color: rgba(0,0,0,0.6); line-height: 1; cursor: pointer; -webkit-tap-highlight-color: transparent; }
.pip.existing { background: var(--pip); border-color: var(--pip); box-shadow: 0 0 20px color-mix(in srgb, var(--pip) 85%, transparent), 0 0 40px color-mix(in srgb, var(--pip) 45%, transparent); }
.pip.round { background: var(--pip); border-color: var(--pip); box-shadow: 0 0 16px color-mix(in srgb, var(--pip) 60%, transparent); }

/*
 * The other mark styles.
 *
 * Every one of them keeps the pip's hit box exactly as it is — only the paint changes — so a
 * tap lands in the same place whichever style is chosen. That matters more than it sounds:
 * these are tapped mid-throw.
 */

/* Classic: how a board is actually scored. The glyph carries the mark, so the tile behind it
   stays empty and the slash, cross and ring do the talking. */
.pips-marks .pip {
  background: transparent;
  border-color: rgba(255, 255, 255, 0.18);
  color: var(--pip);
  text-shadow: 0 0 14px color-mix(in srgb, var(--pip) 70%, transparent);
}
.pips-marks .pip.existing,
.pips-marks .pip.round {
  background: transparent;
  border-color: color-mix(in srgb, var(--pip) 45%, transparent);
  box-shadow: none;
}
/* The ring is drawn as a glyph rather than a border, so it wants a little less weight. */
.pips-marks .pip { font-weight: 800; }

/* Dots: a small round mark centred in the same tile. */
.pips-dots .pip {
  background: transparent;
  border-color: transparent;
  box-shadow: none;
  position: relative;
}
.pips-dots .pip::after {
  content: '';
  width: 42%; aspect-ratio: 1;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  transition: background 0.2s, box-shadow 0.2s;
}
.pips-dots .pip.existing::after,
.pips-dots .pip.round::after {
  background: var(--pip);
  box-shadow: 0 0 16px color-mix(in srgb, var(--pip) 75%, transparent);
}

/* Outline: the edge carries the colour and the middle stays empty. */
.pips-outline .pip {
  background: transparent;
  border-color: rgba(255, 255, 255, 0.2);
  color: var(--pip);
}
.pips-outline .pip.existing,
.pips-outline .pip.round {
  background: transparent;
  border-color: var(--pip);
  box-shadow: inset 0 0 12px color-mix(in srgb, var(--pip) 35%, transparent),
              0 0 14px color-mix(in srgb, var(--pip) 45%, transparent);
}

.closed-badge { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); font-size: 12px; font-weight: 800; letter-spacing: 0.1em; color: var(--pink); text-transform: uppercase; font-family: var(--font-display); opacity: 0.7; z-index: 2; }
.hit-badge { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); font-size: 22px; font-weight: 900; font-family: var(--font-display); color: var(--pink); filter: drop-shadow(0 0 8px rgba(255,45,120,0.6)); z-index: 2; }
.hit-badge.invisible { opacity: 0; pointer-events: none; }

.board-avatar-bg {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  pointer-events: none; overflow: hidden; z-index: 0;
}
.board-avatar-bg img { width: 90%; height: 95%; object-fit: contain; object-position: center; opacity: 0.7; }
.board-avatar-bg span { font-size: 65dvh; line-height: 1; opacity: 0.7; filter: drop-shadow(0 0 24px rgba(0,0,0,0.4)); }

.corner-avatar {
  position: absolute; bottom: 80px; right: 16px; z-index: 2;
  font-size: clamp(56px, 9dvh, 90px); line-height: 1;
  opacity: 0.85; pointer-events: none;
}
.corner-avatar img { width: clamp(56px, 9dvh, 90px); height: clamp(56px, 9dvh, 90px); object-fit: cover; border-radius: 8px; }

.submit-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 20px; padding-bottom: calc(8px + env(safe-area-inset-bottom));
  border-top: 2px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.03); flex-shrink: 0; gap: 16px;
  position: relative; z-index: 1;
}
.hits-text { color: var(--pink); font-weight: 700; font-size: 15px; }
.muted { color: var(--text-muted); font-weight: 700; font-size: 15px; }
.round-label-text { font-weight: 900; font-size: 20px; letter-spacing: 0.06em; text-shadow: 0 0 12px currentColor; }
.submit-inline-btn {
  flex-shrink: 0;
  height: 54px;
  padding: 0 36px;
  font-size: clamp(42px, 6.2dvh, 62px); font-weight: 900; font-family: var(--font-display);
  letter-spacing: 0.08em; text-transform: uppercase; cursor: pointer;
  position: relative; overflow: hidden;
  background: #dc2626 !important; color: #fff !important; border: none !important;
  box-shadow: 3px 3px 0 rgba(0,0,0,0.5);
}
.submit-inline-btn:disabled { opacity: 0.4; }

@media (orientation: landscape) and (max-height: 900px) {
  .cricket-board-scroll { overflow: hidden; display: flex; flex-direction: column; }
  .cricket-board { flex: 1; height: 100%; min-height: 0; padding: 3px 12px; gap: 3px; }
  .board-tile { min-height: 0; padding: 2px 14px; }
  .target-label { font-size: clamp(28px, 6dvh, 60px); width: clamp(70px, 10dvh, 120px); }
  .target-label-bull { font-size: clamp(36px, 8dvh, 78px); }
  .pips-wrap { gap: 8px; padding: 6px 0; margin-left: 10px; }
  .pip { border-radius: 6px; border-width: 2px; }
  .hit-badge { font-size: 16px; }
  .closed-badge { font-size: 9px; }
  .submit-row { min-height: 64px; padding: 4px 16px; padding-bottom: calc(4px + env(safe-area-inset-bottom)); }
  .submit-inline-btn { height: 48px; padding: 0 20px; font-size: 26px; }
}

@media (max-width: 767px) {
  .cricket-board { padding: 5px 8px; gap: 5px; }
  .board-tile { padding: 6px 12px; min-height: 56px; }
  .target-label { font-size: clamp(70px, 13dvh, 120px); width: clamp(100px, 14dvh, 150px); }
  .target-label-bull { font-size: clamp(90px, 17dvh, 155px); }
  .pips-wrap { gap: 16px; margin-left: 16px; }
  .hit-badge { font-size: 16px; }
  .closed-badge { font-size: 9px; }
  .submit-row { min-height: 74px; padding: 8px 12px; padding-bottom: calc(8px + env(safe-area-inset-bottom)); }
  .submit-inline-btn { height: 58px; padding: 0 28px; font-size: 32px; }
}

@media (orientation: portrait) {
  .cricket-board-scroll { overflow: hidden; display: flex; flex-direction: column; }
  .cricket-board { flex: 1; height: 100%; min-height: 0; padding: 4px 8px; gap: 4px; }
  .board-tile { min-height: 0; padding: 4px 12px; }
  .target-label { font-size: clamp(52px, 10dvh, 108px); width: clamp(86px, 12dvh, 140px); }
  .target-label-bull { font-size: clamp(68px, 13dvh, 140px); }
  .pips-wrap { gap: 12px; padding: 6px 0; margin-left: 16px; }
}
</style>
